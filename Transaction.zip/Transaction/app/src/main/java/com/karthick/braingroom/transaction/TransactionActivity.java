package com.karthick.braingroom.transaction;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.karthick.braingroom.transaction.utils.SharedPrefs;

public class TransactionActivity extends AppCompatActivity {

    EditText edtAccountNumber;
    EditText edtAmount;
    Button btnSendMoney;
    Button btnBalanceAmount;
    Button btnSummary;
    Button btnLogOut;
    TextView txtName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        edtAccountNumber = findViewById(R.id.edt_transfer_acc_number);
        edtAmount = findViewById(R.id.edt_transfer_amount);
        btnSendMoney = findViewById(R.id.btn_send_money);
        btnBalanceAmount = findViewById(R.id.btn_amt_balance);
        btnSummary = findViewById(R.id.btn_summary);
        btnLogOut = findViewById(R.id.btn_logout);

        btnBalanceAmount.setOnClickListener(new View.OnClickListener() {

            Button btnBack;
            TextView txtRubies;

            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TransactionActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.balance_amount, null);
                builder.setView(mView);
                final AlertDialog dialog = builder.create();
                dialog.show();

                btnBack = mView.findViewById(R.id.btn_back);
                txtRubies = mView.findViewById(R.id.edt_rs);

                btnBack.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }
        });

        btnSummary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TransactionActivity.this, SummaryActivity.class);
                startActivity(intent);
            }
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             //   SharedPrefs.saveSharedSetting(TransactionActivity.this, "Transaction", "false");
                Intent intent = new Intent(TransactionActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();

    }
}

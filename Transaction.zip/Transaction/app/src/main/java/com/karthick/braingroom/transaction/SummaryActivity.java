package com.karthick.braingroom.transaction;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.karthick.braingroom.transaction.adapter.SummaryAdapter;

import java.util.ArrayList;

public class SummaryActivity extends AppCompatActivity {


    private ListView listView;
    private ArrayList<String> stringArrayList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        listView = findViewById(R.id.listView);

     //   setData();

        stringArrayList = new ArrayList<>();
        stringArrayList.add("Quỳnh Trang");
        stringArrayList.add("Hoàng Biên");
        stringArrayList.add("Đức Tuấn");
        stringArrayList.add("Karthick Raja");
        stringArrayList.add("Xuân Lưu");
        stringArrayList.add("Phạm Thanh");
        stringArrayList.add("Kim Kiên");
        stringArrayList.add("Ngô Trang");
        stringArrayList.add("Thanh Ngân");
        stringArrayList.add("Nguyễn Dương");
        stringArrayList.add("Quốc Cường");
        stringArrayList.add("Trần Hà");

        adapter = new SummaryAdapter(this, R.layout.list_summary, stringArrayList);
        listView.setAdapter(adapter);
    }

//    private void setData() {
//        stringArrayList = new ArrayList<>();
//        stringArrayList.add("Quỳnh Trang");
//        stringArrayList.add("Hoàng Biên");
//        stringArrayList.add("Đức Tuấn");
//        stringArrayList.add("Đặng Thành");
//        stringArrayList.add("Xuân Lưu");
//        stringArrayList.add("Phạm Thanh");
//        stringArrayList.add("Kim Kiên");
//        stringArrayList.add("Ngô Trang");
//        stringArrayList.add("Thanh Ngân");
//        stringArrayList.add("Nguyễn Dương");
//        stringArrayList.add("Quốc Cường");
//        stringArrayList.add("Trần Hà");
//    }
}


package com.karthick.braingroom.transaction.adapter;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.karthick.braingroom.transaction.R;
import com.karthick.braingroom.transaction.SummaryActivity;

import java.util.List;
import java.util.Objects;

public class SummaryAdapter extends ArrayAdapter<String> {
 
    private SummaryActivity activity;
    private List<String> friendList;
 
    public SummaryAdapter(SummaryActivity context, int resource, List<String> objects) {
        super(context, resource, objects);
        this.activity = context;
        this.friendList = objects;
    }
 
    @Override
    public int getCount() {
        return friendList.size();
    }
 
    @Override
    public String getItem(int position) {
        return friendList.get(position);
    }
 
    @Override
    public long getItemId(int position) {
        return position;
    }
 
    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        // If holder not exist then locate all view from UI file.
        if (convertView == null) {
            // inflate UI from XML file
            convertView = inflater.inflate(R.layout.list_summary, parent, false);
            // get all UI view
            holder = new ViewHolder(convertView);
            // set tag for holder
            convertView.setTag(holder);
        } else {
            // if holder created, get tag from view
            holder = (ViewHolder) convertView.getTag();
        }
 
        holder.friendName.setText(getItem(position));
 
        //get first letter of each String item
        String firstLetter = String.valueOf(Objects.requireNonNull(getItem(position)).charAt(0));
 
        ColorGenerator generator = ColorGenerator.MATERIAL; // or use DEFAULT
        // generate random color
        int color = generator.getColor(Objects.requireNonNull(getItem(position)));
        //int color = generator.getRandomColor();

        TextDrawable drawable = TextDrawable.builder()
                .buildRound(firstLetter, color); // radius in px

        holder.imageView.setImageDrawable(drawable);
//
        return convertView;
    }
 
    private class ViewHolder {
        private ImageView imageView;
        private TextView friendName;
 
        ViewHolder(View v) {
            imageView = v.findViewById(R.id.img_summary);
            friendName = v.findViewById(R.id.txt_summary_name);
        }
    }
}
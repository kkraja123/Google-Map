package com.karthick.braingroom.transaction;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.karthick.braingroom.transaction.utils.Constants;
import com.karthick.braingroom.transaction.utils.SharedPrefs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    Button btnLogin;
    TextView txtRegister;
    TextView txtForgotPassword;
    EditText edtEmail;
    EditText edtPassword;
    ImageView imgPasswordShow;
    ImageView imgPasswordHide;
    ProgressBar progressBar;
    LinearLayout linearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtRegister = findViewById(R.id.txt_log_register);
        btnLogin = findViewById(R.id.btn_log_sign_in);
        txtForgotPassword = findViewById(R.id.txt_log_forgot);
        edtEmail = findViewById(R.id.edt_log_email);
        edtPassword = findViewById(R.id.edt_log_password);
        imgPasswordHide = findViewById(R.id.img_password_hide);
        imgPasswordShow = findViewById(R.id.img_password_show);
        progressBar = findViewById(R.id.progress_bar);
        linearLayout = findViewById(R.id.linear_forgot);

        txtRegister.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
                finish();
            }
        });

        txtForgotPassword.setOnClickListener(new OnClickListener() {

            Button btnSubmit;
            EditText edtForgotEmail;

            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.forgot_password, null);
                builder.setView(mView);
                final AlertDialog dialog = builder.create();
                dialog.show();

                btnSubmit = mView.findViewById(R.id.btn_submit);
                edtForgotEmail = mView.findViewById(R.id.edt_forgot_email);

                btnSubmit.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Snackbar.make(linearLayout, "success", Snackbar.LENGTH_LONG).show();
                        dialog.dismiss();

                    }
                });
            }
        });


        btnLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                String tag_string_req = "string_req";
                String url = Constants.SERVER_URL + Constants.REGISTER_LOGIN_URL;

                final String email = edtEmail.getText().toString();
                final String password = edtEmail.getText().toString();


                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());


                StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        // SharedPrefs.saveSharedSetting(MainActivity.this, "Transaction", "false");

                        try {

                            JSONObject jsonObject = new JSONObject(response);

                            String status = jsonObject.getString("status");
                            if (email.isEmpty() || password.isEmpty()) {

                                Toast.makeText(MainActivity.this, "Enter UserName or Password", Toast.LENGTH_SHORT).show();

                            } else {
                                if (response != null) {

                                    if (status.toLowerCase().equals("true")) {

                                        Intent intent = new Intent(MainActivity.this, TransactionActivity.class);
                                        startActivity(intent);
                                        finish();

                                    } else if (status.toLowerCase().equals("false")) {
                                        Toast.makeText(MainActivity.this, jsonObject.getString("data"), Toast.LENGTH_SHORT).show();
                                    }

                                } else {
                                    Toast.makeText(MainActivity.this, "no data found", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener()

                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();

                    }
                })

                {
                    @Override
                    protected Map<String, String> getParams() {

                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Content-Type", "application/json");
                        params.put("email", email);
                        params.put("password", password);
                        params.put("requestmethod", "Login");
                        return params;
                    }
                };
                //AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
                requestQueue.add(strReq);
            }
        });

        //  checkActivity();

        imgPasswordShow.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                imgPasswordShow.setVisibility(View.GONE);
                imgPasswordHide.setVisibility(View.VISIBLE);
                edtPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
        });


        imgPasswordHide.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                imgPasswordHide.setVisibility(View.GONE);
                imgPasswordShow.setVisibility(View.VISIBLE);
                edtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });

    }


//    private void checkActivity() {
//        Boolean check = Boolean.valueOf(SharedPrefs.readSharedSetting(MainActivity.this, "Transaction", "false"));
//
//        Intent intent = new Intent(MainActivity.this, TransactionActivity.class);
//
//        if (check) {
//            startActivity(intent);
//            finish();
//        }
//    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}


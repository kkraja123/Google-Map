package com.karthick.braingroom.transaction;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.karthick.braingroom.transaction.utils.Constants;
import com.karthick.braingroom.transaction.utils.SharedPrefs;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity implements TextWatcher {

    Button btnRegister;
    TextView txtLogin;
    EditText edtFirstName;
    EditText edtLastName;
    EditText edtUserName;
    EditText edtEmail;
    EditText edtPassword;
    EditText edtConfirmPassword;
    EditText edtPhoneNumber;
    EditText edtAccountNumber;
    EditText edtAmount;
    ImageView imgPasswordShow;
    ImageView imgPasswordHide;
    ImageView imgConfirmPasswordShow;
    ImageView imgConfirmPasswordHide;
    static final char space = ' ';

    public final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
            "[a-zA-Z0-9+._%-+]{1,256}" +
                    "@" +
                    "[a-zA-Z0-9][a-zA-Z0-9-]{0,64}" +
                    "(" +
                    "." +
                    "[a-zA-Z0-9][a-zA-Z0-9-]{0,25}" +
                    ")+"
    );

    public final Pattern PASSWORD_PATTERN = Pattern.compile(
            "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z]).{0,100})"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        setTitle("Registration");

        btnRegister = findViewById(R.id.btn_register);
        txtLogin = findViewById(R.id.txt_have_account);
        edtFirstName = findViewById(R.id.edt_first_name);
        edtLastName = findViewById(R.id.edt_last_name);
        edtUserName = findViewById(R.id.edt_user_name);
        edtEmail = findViewById(R.id.edt_email);
        edtPassword = findViewById(R.id.edt_pwd);
        edtConfirmPassword = findViewById(R.id.edt_confirm_pwd);
        edtPhoneNumber = findViewById(R.id.edt_Phone_number);
        edtAccountNumber = findViewById(R.id.edt_acc_number);
        edtAmount = findViewById(R.id.edt_amount);
        imgConfirmPasswordHide = findViewById(R.id.img_confirm_password_hide);
        imgConfirmPasswordShow = findViewById(R.id.img_confirm_password_show);
        imgPasswordHide = findViewById(R.id.img_password_hide_register);
        imgPasswordShow = findViewById(R.id.img_password_show_register);

        edtAccountNumber.addTextChangedListener(new RegisterActivity());

        imgPasswordShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgPasswordShow.setVisibility(View.GONE);
                imgPasswordHide.setVisibility(View.VISIBLE);
                edtPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
        });


        imgPasswordHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgPasswordHide.setVisibility(View.GONE);
                imgPasswordShow.setVisibility(View.VISIBLE);
                edtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });

        imgConfirmPasswordShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgConfirmPasswordShow.setVisibility(View.GONE);
                imgConfirmPasswordHide.setVisibility(View.VISIBLE);
                edtConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
        });


        imgConfirmPasswordHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgConfirmPasswordHide.setVisibility(View.GONE);
                imgConfirmPasswordShow.setVisibility(View.VISIBLE);
                edtConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getRegister();
            }
        });

        txtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void getRegister() {

        final String firstName = edtFirstName.getText().toString();
        final String lastName = edtLastName.getText().toString();
        final String userName = edtUserName.getText().toString();
        final String email = edtEmail.getText().toString();
        final String password = edtPassword.getText().toString();
        final String confirmPassword = edtConfirmPassword.getText().toString();
        final String phoneNumber = edtPhoneNumber.getText().toString();
        final String accountNumber = edtAccountNumber.getText().toString();
        final String amount = edtAmount.getText().toString();

        if (firstName.equals("")) {
            edtFirstName.setError("Please Enter First Name");
        } else if (lastName.equals("")) {
            edtLastName.setError("Please Enter Last Name");
        } else if (userName.equals("")) {
            edtUserName.setError("Please Enter UserName");
        } else if (email.equals("")) {
            edtEmail.setError("Please Enter Email");
        } else if (!checkEmail(email)) {
            edtEmail.setError("Please Enter Valid Email");
        } else if (password.equals("")) {
            edtPassword.setError("Please Enter Password");
        } else if (!checkPassword(password)) {
            edtPassword.setError("Password should have minimum one uppercase one smaller case and one number");
        } else if (confirmPassword.equals("")) {
            edtConfirmPassword.setError("Please Enter Confirm Password");
        } else if (!confirmPassword.equals(password)) {
            edtConfirmPassword.setError("Password does not match");
        } else if (phoneNumber.equals("")) {
            edtPhoneNumber.setError("Please Enter Phone Number");
        } else if (phoneNumber.length() < 10 || phoneNumber.length() > 10) {
            edtPhoneNumber.setError("Phone number should be 10 digits");
        } else if (accountNumber.equals("")) {
            edtAccountNumber.setError("Please Enter Account Number");
        } else if (accountNumber.length() > 14 || accountNumber.length() < 14) {
            edtAccountNumber.setError("Account number should be 12 digits");
        } else if (amount.equals("")) {
            edtAmount.setError("Please Enter Amount");
        } else {
            String tag_string_req = "string_req";
            String url = Constants.SERVER_URL + Constants.REGISTER_LOGIN_URL;

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

            StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    try {

                        JSONObject jsonObject = new JSONObject(response);

                        String status = jsonObject.getString("status");

                        Toast.makeText(RegisterActivity.this, "Register Successful", Toast.LENGTH_SHORT).show();

                        if (response != null) {

                            if (status.toLowerCase().equals("true")) {

                            //    SharedPrefs.saveSharedSetting(RegisterActivity.this,"Transaction","true");

                                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();

                            } else if (status.toLowerCase().equals("false")) {
                                Toast.makeText(RegisterActivity.this, jsonObject.getString("data"), Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            Toast.makeText(RegisterActivity.this, "no data found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener()

            {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(RegisterActivity.this, error.toString(), Toast.LENGTH_SHORT).show();

                }
            })

            {
                @Override
                protected Map<String, String> getParams() {

                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/json");
                    params.put("email", email);
                    params.put("password", password);
                    params.put("requestmethod", "Register");
                    params.put("username",userName);
                    params.put("firstname",firstName);
                    params.put("lastname",lastName);
                    params.put("mobile",phoneNumber);
                    params.put("amount",amount);
                    params.put("accnumber",accountNumber);
                    return params;
                }
            };
            //AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
            requestQueue.add(strReq);

        }
    }

    private boolean checkEmail(String eemail) {
        return EMAIL_ADDRESS_PATTERN.matcher(eemail).matches();
    }

    private boolean checkPassword(String ppassword) {
        return PASSWORD_PATTERN.matcher(ppassword).matches();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if (s.length() > 0 && (s.length() % 5) == 0) {
            final char c = s.charAt(s.length() - 1);
            if (space == c) {
                s.delete(s.length() - 1, s.length());
            }
        }
        // Insert char where needed.
        if (s.length() > 0 && (s.length() % 5) == 0) {
            char c = s.charAt(s.length() - 1);
            // Only if its a digit where there should be a space we insert a space
            if (Character.isDigit(c) && TextUtils.split(s.toString(), String.valueOf(space)).length <= 3) {
                s.insert(s.length() - 1, String.valueOf(space));
            }
        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();

    }
}

package com.karthick.braingroom.transaction.utils;

public class Constants {

    public static final String SERVER_URL = "http://www.platosys.com/mafoi/";

    public static final String REGISTER_LOGIN_URL = "mafai.php?";

    public static final String FORGOT_PASSWORD_URL = "forget_password.php";
}
